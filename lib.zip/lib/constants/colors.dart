import 'package:flutter/material.dart';

const dashBoardColor = Color.fromRGBO(105, 106, 183, 1);
const splashScreenColorBottom = Colors.lightBlue;
const splashScreenColorTop = Color.fromRGBO(105, 106, 183, 1);
const appbarcolor = Color.fromRGBO(51, 51, 102, 1);
const leaveCardcolor = Color(0xFF8685E5);
