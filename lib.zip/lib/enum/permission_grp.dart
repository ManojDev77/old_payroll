enum PermissionGroup {
  locationAlways,
}
