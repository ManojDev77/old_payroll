import 'package:flutter/material.dart';

const dashBoardColor = Colors.blue;
const splashScreenColorBottom = Colors.blue;
const splashScreenColorTop = Colors.blue;
const appbarcolor = Colors.blue;
const leaveCardcolor = Color(0xFF8685E5);
