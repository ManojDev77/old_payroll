import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:rxdart/rxdart.dart';

class NotificationService extends ChangeNotifier {
  static final _notifications = FlutterLocalNotificationsPlugin();
  static final onNotification = BehaviorSubject<String>();

  static Future init({bool initScheduled = false}) async {
    const androidInitilize = AndroidInitializationSettings('ic_launcher');
    const iOSinitilize = IOSInitializationSettings();
    const initilizationsSettings =
        InitializationSettings(android: androidInitilize, iOS: iOSinitilize);
    await _notifications.initialize(
      initilizationsSettings,
      onSelectNotification: (payload) async {
        onNotification.add(payload!);
      },
    );

    final details = await _notifications.getNotificationAppLaunchDetails();
    if (details != null && details.didNotificationLaunchApp) {
      onNotification.add(details.payload!);
    }
  }

  static Future showNotification(
      int id, String title, String body, String payload) async {
    _notifications.show(id, title, body, await _notificatioDetails(),
        payload: payload);
  }

  static Future _notificatioDetails() async {
    return const NotificationDetails(
      android: AndroidNotificationDetails('channel id', 'Payroll',
          channelDescription: 'channel discription',
          importance: Importance.high,
          channelShowBadge: true),
      iOS: IOSNotificationDetails(),
    );
  }

  // static Future scheduledNotification(
  //     {int id,
  //     String title,
  //     String body,
  //     String payload,
  //     DateTime scheduleTime}) async {
  //   _notifications.zonedSchedule(
  //       id,
  //       title,
  //       body,
  //       _scheduleWeekly(scheduleTime, days: [DateTime.monday, DateTime.sunday]),
  //       await _notificatioDetails(),
  //       payload: payload,
  //       androidAllowWhileIdle: true,
  //       uiLocalNotificationDateInterpretation:
  //           UILocalNotificationDateInterpretation.absoluteTime,
  //       matchDateTimeComponents: DateTimeComponents.dayOfWeekAndTime);
  //   print("object");
  //   print(_scheduleWeekly(scheduleTime,
  //       days: [DateTime.monday, DateTime.sunday]));
  // }

  static Future scheduledNotification(
      {int? id,
      String? title,
      String? body,
      String? payload,
      DateTime? scheduleTime}) async {
    _notifications.schedule(
        id!,
        title,
        body,
        _scheduleWeekly(scheduleTime!, days: [
          DateTime.monday,
          DateTime.tuesday,
          DateTime.wednesday,
          DateTime.thursday,
          DateTime.friday,
          DateTime.saturday
        ]),
        await _notificatioDetails(),
        payload: payload);
  }

  static DateTime _scheduleDaily(DateTime schedule) {
    final now = DateTime.now();

    final scheduleDate = DateTime(
        now.year, now.month, now.day, schedule.hour, schedule.minute, 00);

    return scheduleDate.isBefore(now)
        ? scheduleDate.add(const Duration(days: 1))
        : scheduleDate;
  }

  static DateTime _scheduleWeekly(DateTime time, {List<int>? days}) {
    DateTime scheduleDate = _scheduleDaily(time);
    while (!days!.contains(scheduleDate.weekday)) {
      scheduleDate = scheduleDate.add(const Duration(days: 1));
    }
    return scheduleDate;
  }

  // static tz.TZDateTime _scheduleDaily(DateTime schedule) {
  //   final now = tz.TZDateTime.now(tz.UTC);

  //   final scheduleDate = tz.TZDateTime(tz.UTC, now.year, now.month, now.day,
  //       schedule.hour, schedule.minute, 00);

  //   return scheduleDate.isBefore(now)
  //       ? scheduleDate.add(Duration(days: 1))
  //       : scheduleDate;
  // }

  // static tz.TZDateTime _scheduleWeekly(DateTime time, {List<int> days}) {
  //   tz.TZDateTime scheduleDate = _scheduleDaily(time);
  //   while (!days.contains(scheduleDate.weekday)) {
  //     scheduleDate = scheduleDate.add(Duration(days: 1));
  //   }
  //   return scheduleDate;
  // }

  static void cancel(int id) => _notifications.cancel(id);
  static void cancelAll() => _notifications.cancelAll();

  static Future scheludedNoti(
      {int? id,
      String? title,
      String? body,
      String? payload,
      DateTime? scheduleTime}) async {
    await _notifications.schedule(
      id!,
      title,
      body,
      _scheduletime(scheduleTime!),
      await _notificatioDetails(),
      payload: payload,
      androidAllowWhileIdle: true,
    );
  }

  static DateTime _scheduletime(DateTime schedule) {
    final now = DateTime.now().toLocal();

    final scheduleDate = DateTime(now.year, now.month, now.day, schedule.hour,
        schedule.minute, schedule.second);
    return scheduleDate.isBefore(now)
        ? scheduleDate.add(const Duration(days: 1))
        : scheduleDate;
  }
}
